@extends('layouts.deshboard')

@section('section')
 <div class="container">
    <div class="card mt-5">
        <div class="card-header">
            <h2 class="text-center text-danger">USER DATA SHOW</h2>
            <a href="{{ route('user.create') }}" class="btn btn-success btn-sm float-end">Add User</a>
        </div>
        <div class="card-body">
            <table class="table table-sm table-striped table-bordered">
            <thead class="text-primary">
                <th>S/N</th>
                <th>Full Name</th>
                <th>Email</th>
                <th colspan="2">Action</th>

            </thead>
            <tbody>
                @foreach ($users as  $item )
                <tr>
                <td>{{$item-> id }}</td>
                <td>{{$item-> name }}</td>
                <td>{{$item-> email }}</td>
                <td><a href="" class="btn btn-sm btn-success">Edit</a></td>
                <td><a href="" class="btn btn-sm btn-danger">Delete</a></td>

                </tr>
                @endforeach
            </tbody>
            </table>
        </div>
    </div>
</div>


@endsection
