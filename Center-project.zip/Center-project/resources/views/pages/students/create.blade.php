@extends('layouts.deshboard')

@section('section')
<div class="container">
    <div class="card mt-5">
        <div class="card-hearder"><h1 class="text-center text-primary ">Add Students Records</h1>
        <hr class="w-25 mx-auto text-danger">
        </div>
        <div class="card-body">
            <form  action="{{ route('students.store') }}" method="post">
                @csrf
                <div class="mb-3">
                    <label for="formGroupExampleInput" class="form-label">Full Name</label>
                    <input type="text" class="form-control"  name="name" value="{{ old('name') }}" placeholder="Enter your full name ">
                    @error('name')
                    <span class="text-danger">{{ $message }}</span>

                    @enderror
                  </div>
                  <div class="mb-3">
                    <label for="formGroupExampleInput" class="form-label">Email</label>
                    <input type="email" class="form-control" name="email" value="{{ old('email') }}" placeholder="Enter your Email ">
                    @error('email')
                    <span class="text-danger">{{ $message }}</span>

                    @enderror
                  </div>
                   <div class="mb-3">
                    <label for="formGroupExampleInput" class="form-label">Phone Number</label>
                    <input type="text" class="form-control" name="phone_number" value="{{ old('phone_number') }}" placeholder="Enter your phone Number ">
                    @error('phone_number')
                    <span class="text-danger">{{ $message }}</span>

                    @enderror
                </div>
                <div class="mb-3">
                    <label for="formGroupExampleInput" class="form-label">Adress</label>
                    <input type="text" class="form-control" name="address" value="{{ old('address') }}" placeholder="Enter your phone Number ">
                    @error('address')
                    <span class="text-danger">{{ $message }}</span>

                    @enderror
                </div>

                <div class="mb-3">
                    <label for="formGroupExampleInput" class="form-label">Cnic_Number</label>
                    <input type="text" class="form-control" name="cnic" value="{{ old('cnic') }}" placeholder="Enter your phone Number ">
                    @error('cnic')
                    <span class="text-danger">{{ $message }}</span>

                    @enderror
                </div>
                <button class="btn btn-primary" type="submit">Save</button>
            </form>
        </div>
    </div>
</div>


@endsection
