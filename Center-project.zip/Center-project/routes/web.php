<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\UserController;
use App\Http\Controllers\StudentsController;



Route::get('/', function () {
    return view('frontpages.home');
});



Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/user', [UserController::class, 'show'])->name('user');
Route::get('/user/create', [UserController::class, 'create'])->name('user.create');
// Route::post('/user/store', [UserController::class, 'store'])->name('user.store');

// students route
Route::get('/student', [StudentsController::class, 'index'])->name('students');
Route::get('/student/create', [StudentsController::class, 'create'])->name('students.create');
Route::post('/student/store', [StudentsController::class, 'store'])->name('students.store');

// Route::resource('/students', StudentsController::class);
