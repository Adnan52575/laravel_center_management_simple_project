<?php

namespace App\Http\Controllers;

use App\Models\Students;
use Illuminate\Http\Request;

class StudentsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $student = Students::all();

        return view('pages.students.show',compact('student'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //

        return view('pages.students.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //

        // $request->validate([
        //     'name' => 'required|string',
        //     'email' => 'required|email|unique:users',
        //     'phone_number' => 'required',
        //     'address' => 'required',
        //     'cnic' => 'required',

        // ]);

        //registration proeceess
        $new_Student= new Students;
        $new_Student->name = request('name');
        $new_Student->email = request('email');
        $new_Student->phone_number = request('phone_number');
        $new_Student->address = request('address');
        $new_Student->cnic = request('cnic');

        $new_Student->save();

       // return response()->with('success','user created successfully');
       return redirect()->route('students')->with('success','student add successfully');

    }

    /**
     * Display the specified resource.
     */
    public function show(Students $students)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Students $students)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Students $students)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Students $students)
    {
        //
    }
}
