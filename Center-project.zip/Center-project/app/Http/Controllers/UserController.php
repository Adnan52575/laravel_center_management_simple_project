<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;



class UserController extends Controller
{
    public function show(){
        $users = user::all();
        // $user = user::all();

        return view('pages.showuser', compact('users'));
    }

    public function create(){
        return view('pages.create');
    }

    public function store(Request $request){
        //store user
        $request->validate([
            'name' => 'required|string',
            'email' => 'required|email|unique:users',
            'password' => 'required|confirmed|min:4|max:8',

        ]);

        //registration proeceess
        $new_user= new User;
        $new_user->name = $request->name;
        $new_user->email = $request->email;
        $new_user->password = Hash::make($request->password);
        $new_user->save();

       // return response()->with('success','user created successfully');
       return redirect('pages.showuser')->with('success','User add successfully');

    }
}
